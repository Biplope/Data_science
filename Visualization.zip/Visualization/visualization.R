library(tidyverse)
library(dplyr)
library(scales)
library(ggrepel)

setwd("C:\\Users\\mahar\\OneDrive\\Desktop\\Bip_datascience\\cleaning")

euro <- dollar_format(prefix = "\u20ac", big.mark = ",")

#House Prices


Towns_Population = read_csv("cleanedData\\cleanedPopulation.csv") %>% 
  select(-Year) 
HousePrices=read_csv("CleanedData\\cleanedHousePricing.csv", show_col_types = FALSE)


HousePricesclean <- HousePrices %>% 
  select(-PostCode) %>% 
  left_join(Towns_Population, by ="shortPostcode")


HousePricesclean$County[HousePricesclean$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"


House_town = HousePricesclean %>% 
  #filter(County=="OXFORDSHIRE"|County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  filter(County=="OXFORDSHIRE"|County=="YORKSHIRE") %>% 
  group_by(Town,District,County,Year) %>% 
  summarise(AveragePrice= mean(Price)) %>% 
  ungroup(Town,District,County,Year) %>%
  na.omit()
write.csv(House_town,"CleanedData\\City_Home.csv",row.names = FALSE)



# BOXPLOT Average house prices (2022)
House_town %>% 
  group_by(District) %>% 
  ggplot(aes(x = District, y = AveragePrice, fill=District)) +
  scale_y_continuous(limits=c(0,2000000), breaks = seq(0,2000000,200000), 
                     label = euro) +
  geom_boxplot() +
  coord_flip() +
  labs(title="2022 house prices by district")


# BARGRAPH house prices by district (2019-2022)

HousePricesclean %>%
  group_by(District) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = District, y = AveragePrice)) +
  geom_bar(position = "stack",stat = "identity", fill = "cornflowerblue") +
  scale_y_continuous(limits=c(0,5000000),breaks = seq(0, 5000000, 30000),
                     label = euro) +
  geom_text(aes(label = euro(AveragePrice)),
            vjust = -0.25) +
  labs(title = "2019-2022 Average house prices by district") +
  coord_flip()


#LINEGRAPH Average house prices by year (2019-2022)

HousePricesclean %>%
  mutate(Year = as.numeric(Year)) %>%  # Convert Year to numeric if not already
  group_by(Year) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = Year, y = AveragePrice)) +
  geom_line(size = 1.5, color = "lightgrey") +
  geom_text(aes(label = dollar_format()(AveragePrice)), vjust = -0.85) +
  scale_y_continuous(labels = dollar_format(prefix = "$"), breaks = seq(0, 300000, 5000)) +
  scale_x_continuous(breaks = seq(2019, 2022, 1), minor_breaks = NULL) +
  geom_point(size = 2, color = "steelblue") +
  labs(title = "2019-2022 Average house prices by year",
       x = "Year",
       y = "Average Price")

#-----------------------------------BROADBAND------------------------------
Towns = read_csv("CleanedData\\cleanedPopulation.csv")%>% 
  select(shortPostcode, Town, District, County)
BroadbandCleaned = read_csv("CleanedData\\cleanedBroadband.csv", show_col_types = FALSE)

broadband=Towns %>% 
  left_join(BroadbandCleaned,by="shortPostcode")
View(broadband)

#-----------Oxfordshire Broadband speed visualization-----------------------

# Oxfordshire Broadband Speeds Visualization
oxfordshire_plot <- broadband %>%
  filter(County == "OXFORDSHIRE") %>%
  ggplot(aes(y = Town)) +
  labs(x = "Download Speed (Mbps)", y = "Town", title = "Oxfordshire Broadband Speeds") +
  geom_bar(aes(x = Avgdownload, fill = "Average"), stat = "identity") +
  geom_bar(aes(x = Mindownload, fill = "Minimum"), stat = "identity") +
  guides(fill = guide_legend("Download Speeds"))

# Yorkshire Broadband Speeds Visualization
yorkshire_plot <- broadband %>%
  filter(County %in% c("YORKSHIRE", "WEST YORKSHIRE", "SOUTH YORKSHIRE", "NORTH YORKSHIRE")) %>%
  ggplot(aes(y = Town)) +
  labs(x = "Download Speed (Mbps)", y = "Town", title = "Yorkshire Broadband Speeds") +
  geom_bar(aes(x = Avgdownload, fill = "Average"), stat = "identity") +
  geom_bar(aes(x = Mindownload, fill = "Minimum"), stat = "identity") +
  guides(fill = guide_legend("Download Speeds"))

# Average Download Speed by District Visualization
average_speed_plot <- broadband %>%
  group_by(County) %>% 
  ggplot(aes(x = Avgdownload, y = County, fill = County)) +
  scale_x_continuous(breaks = seq(0, 200, 10), labels = scales::unit_format(unit = "Mbps")) +
  geom_boxplot() +
  labs(title = "Average Download Speed (Mbps) by District", x = "Average Download Speed",
       y = "District") +
  coord_flip()

# Combine the plots using gridExtra package (or arrangeGrob from ggpubr package)
library(gridExtra)

# Arrange the plots in a grid
grid_arranged <- arrangeGrob(oxfordshire_plot, yorkshire_plot, average_speed_plot, ncol = 1)

# Print the combined plot
print(grid_arranged)





#----------------------------------------CRIME-------------------------------------
Town = read_csv("Data Cleaning\\CleanedData\\PopCleanedData.csv")%>% 
  select(-Year)
crime_Data = read_csv("Data Cleaning\\CleanedData\\CrimeCleanedData.csv")
View(Town)

crimeData = crime_Data %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()

crimeData$County[crimeData$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"

view(crimeData)


# Create the boxplot 2021-2022
crimeData %>%
  filter(CrimeType == "Drugs") %>%
  ggplot(aes(x=District, y=CrimeCount, fill=CrimeType)) +
  geom_boxplot() +
  labs(title=" 2021-2022 Drugs Rate by District")+
  coord_flip()



#========Drug Offence Rate per 10000 in 2021-2022 =========
filtered_data <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

ggplot(data = filtered_data, aes(x = County, y = CrimeCount, fill = CrimeType)) +
  geom_boxplot() +
  labs(title = "Drug Offence Rate per 10000 in 2021-2022") +
  coord_flip()





#radarchart
vehicles=crimeData %>% 
  filter(CrimeType=="Vehicle crime") %>% 
  group_by(CrimeType, CrimeCount, Year,Town,District) %>% 
  select(CrimeType,CrimeCount,Year,Town,District)


radarchart(vehicles)



#piechart
RobberyData <- crimeData %>% 
  filter(CrimeType=="Robbery", Year == 2022) %>%
  group_by(District) %>%
  mutate(sumCount = sum(CrimeCount)) %>% 
  ungroup() %>%
  mutate(perc =sumCount / sum(CrimeCount)) %>% 
  arrange(perc) %>%
  mutate(labels = scales::percent(perc)) %>% 
  distinct(District, sumCount, perc, labels) %>% 
  select(District, sumCount, perc, labels)


RobberyData %>% 
  ggplot(aes(x = "", y = perc, fill = District)) +
  geom_col(color = "white") +
  geom_label(aes(label = labels),color="black",
             position = position_stack(vjust = 0.5),
             show.legend = FALSE) +
  coord_polar(theta = "y") +
  theme_void()+
  labs(title="2022 Robbery by District")



# Filter and calculate drug offense rate per town and county for years 2022 and 2022

Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")
