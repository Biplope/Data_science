library(tidyverse)
library(dplyr)
library(stringi)
library(scales)



setwd("C:\\Users\\mahar\\OneDrive\\Desktop\\Bip_datascience")



#HOUSEPRICING
data2019 = read_csv("data_set\\House Pricing\\House Price-2019.csv", show_col_types = FALSE)
data2020 = read_csv("data_set\\House Pricing\\House Price-2020.csv", show_col_types = FALSE)
data2021 = read_csv("data_set\\House Pricing\\House Price-2021.csv", show_col_types = FALSE)
data2022 = read_csv("data_set\\House Pricing\\House Price-2021.csv", show_col_types = FALSE)





colnames(data2019) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                       "Locality", "Town" , "District", "County", "Type1", "Type2" )
colnames(data2020) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                       "Locality", "Town" , "District", "County", "Type1", "Type2")
colnames(data2021) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                       "Locality", "Town" , "District", "County" , "Type1", "Type2")
colnames(data2022) = c("ID" , "Price", "Year", "PostCode" , "PAON", "SAON", "FL", "House Num", "Flat", "Street Name",
                       "Locality", "Town" , "District", "County" , "Type1", "Type2")



HousePrices = rbind(data2019,data2020,data2021,data2022) %>% 
  na.omit() %>% 
  distinct() %>% 
  as_tibble()
View(HousePrices)



write.csv(HousePrices, "cleaning/cleanedData/Combined_housePricing.csv")



FilteredHousePrices = filter(HousePrices, County == 'OXFORDSHIRE' | County == 'YORK' | County == 'WEST YORKSHIRE' | County == 'NORTH YORKSHIRE' | County == 'SOUTH YORKSHIRE' )



# Replace "YORK" with "YORKSHIRE" in the COUNTY column
FilteredHousePrices$County[FilteredHousePrices$County == "YORK"] <- "YORKSHIRE"



view(FilteredHousePrices)



pattern = ' .*$'



FilteredHousePrices = FilteredHousePrices %>% 
  mutate(shortPostcode=gsub(pattern,"",PostCode)) %>%
  mutate(Year = str_trim(substring(Year, 1,4))) %>% 
  select(PostCode,shortPostcode,Year,PAON,Price) %>% 
  na.omit() %>% 
  distinct() %>% 
  as_tibble()
View(FilteredHousePrices)



# exporting filteredhouseprices data set to  csv
write.csv(FilteredHousePrices, "cleaning/cleanedData/cleanedHousePricing.csv",row.names = FALSE)



#POPULATION
Uncleaned_HousePrices = read_csv('cleaning/cleanedData/Combined_housePricing.csv')
Population = read_csv("data_set\\Population\\Population2011_1656567141570.csv", show_col_types = FALSE)
view(Uncleaned_HousePrices)



FilteredTown = filter(Uncleaned_HousePrices, County == 'OXFORDSHIRE' | County == 'YORK' | County == 'WEST YORKSHIRE' | County == 'NORTH YORKSHIRE' | County == 'SOUTH YORKSHIRE' )
pattern = ' .*$'



Population = Population %>%  
  mutate(shortPostcode=gsub(pattern,"",Postcode)) %>%
  group_by(shortPostcode) %>%
  summarise_at(vars(Population),list(Population2011 = sum)) %>%
  mutate(Population2012= (1.00695353132322269 * Population2011)) %>%
  mutate(Population2013= (1.00669740535540783 * Population2012)) %>%
  mutate(Population2014= (1.00736463978721671 * Population2013)) %>%
  mutate(Population2015= (1.00792367505802859 * Population2014)) %>%
  mutate(Population2015= (1.00792367505802859 * Population2014)) %>%
  mutate(Population2016= (1.00757874492811929 * Population2015)) %>%
  mutate(Population2017= (1.00679374473924223 * Population2016)) %>%
  mutate(Population2018= (1.00605929132212552 * Population2017)) %>%
  mutate(Population2019= (1.00561255390388033 * Population2018)) %>%
  mutate(Population2020= (1.00561255390388033 * Population2019)) %>%
  mutate(Population2021= (1.00561255390388033 * Population2020)) %>%
  mutate(Population2022= (1.00561255390388033 * Population2021)) %>%
  
  select(shortPostcode,Population2019,Population2020,Population2021,Population2022)



FilteredTown = FilteredTown %>% 
  mutate(shortPostcode=gsub(pattern,"",PostCode)) %>%
  mutate(Year = str_trim(substring(Year, 1,4))) %>% 
  left_join(Population,by="shortPostcode") %>% 
  select(PostCode, shortPostcode, Year, Town, District, County, Population2019,Population2020,Population2021,Population2022) %>% 
  group_by(shortPostcode) %>%
  arrange(County) %>% 
  as_tibble() %>% 
  na.omit() %>% 
  distinct()



# Replace "YORK" with "YORKSHIRE" in the COUNTY column
FilteredTown$County[FilteredTown$County == "YORK"] <- "YORKSHIRE"
View(FilteredTown)

write.csv(FilteredTown, "cleaning/cleanedData/cleanedPopulation.csv",row.names = FALSE)



#BROADBAND
Broadband = read_csv("data_set\\Broadband_Speed\\201805_fixed_pc_performance_r03.csv", show_col_types = FALSE)



pattern = ' .*$'
BroadbandData = Broadband %>%
  mutate(shortPostcode=gsub(pattern,"",postcode_space)) %>% 
  mutate(ID = row_number()) %>% 
  select(`ID`, `postcode area`, shortPostcode, `Average download speed (Mbit/s)`,
         `Average upload speed (Mbit/s)`, `Minimum download speed (Mbit/s)`,
         `Minimum upload speed (Mbit/s)`) %>% 
  na.omit()
colnames(BroadbandData) = c( "ID","postcode area", "shortPostcode", "Avgdownload",
                             "Average upload speed (Mbit/s)", "Mindownload",
                             "Minimum upload speed (Mbit/s)")
write.csv(BroadbandData, "cleaning/cleanedData/cleanedBroadband.csv",row.names = FALSE)



#LSOA
CleanedPopulation = read.csv("cleaning/cleanedData/cleanedPopulation.csv" )



LSOA = fread("data_set\\LSOA\\Postcode to LSOA.csv")
pattern = ' .*$'
LSOA_Cleaned = LSOA %>%
  select(lsoa11cd,pcds) %>% 
  mutate(shortPostcode=gsub(pattern,"",pcds)) %>% 
  right_join(CleanedPopulation,by="shortPostcode")  %>% 
  group_by(lsoa11cd) %>% 
  select(lsoa11cd,shortPostcode,Town,District,County)



colnames(LSOA_Cleaned)[1] <- "LSOA code"
#view(LSOA_Cleaned)
write.csv(LSOA_Cleaned,"cleaning/cleanedData/cleanedLSOA.csv",row.names = FALSE,col.names = FALSE)





#CRIME
#OXFORDSHIRE
Crime_2020_05_oxfordshire_ = fread("data_set\\CrimeData\\2020-05\\2020-05-thames-valley-street.csv")
Crime_2020_06_oxfordshire_ = fread("data_set\\CrimeData\\2020-06\\2020-06-thames-valley-street.csv")
Crime_2020_07_oxfordshire_ = fread("data_set\\CrimeData\\2020-07\\2020-07-thames-valley-street.csv")
Crime_2020_08_oxfordshire_ = fread("data_set\\CrimeData\\2020-08\\2020-08-thames-valley-street.csv")
Crime_2020_09_oxfordshire_ = fread("data_set\\CrimeData\\2020-09\\2020-09-thames-valley-street.csv")
Crime_2020_10_oxfordshire_ = fread("data_set\\CrimeData\\2020-10\\2020-10-thames-valley-street.csv")
Crime_2020_11_oxfordshire_ = fread("data_set\\CrimeData\\2020-11\\2020-11-thames-valley-street.csv")
Crime_2020_12_oxfordshire_ = fread("data_set\\CrimeData\\2020-12\\2020-12-thames-valley-street.csv")



Crime_2021_01_oxfordshire_  = fread("data_set\\CrimeData\\2021-01\\2021-01-thames-valley-street.csv")
Crime_2021_02_oxfordshire_  = fread("data_set\\CrimeData\\2021-02\\2021-02-thames-valley-street.csv")
Crime_2021_03_oxfordshire_  = fread("data_set\\CrimeData\\2021-03\\2021-03-thames-valley-street.csv")
Crime_2021_04_oxfordshire_  = fread("data_set\\CrimeData\\2021-04\\2021-04-thames-valley-street.csv")
Crime_2021_05_oxfordshire_  = fread("data_set\\CrimeData\\2021-05\\2021-05-thames-valley-street.csv")
Crime_2021_06_oxfordshire_  = fread("data_set\\CrimeData\\2021-06\\2021-06-thames-valley-street.csv")
Crime_2021_07_oxfordshire_  = fread("data_set\\CrimeData\\2021-07\\2021-07-thames-valley-street.csv")
Crime_2021_08_oxfordshire_  = fread("data_set\\CrimeData\\2021-08\\2021-08-thames-valley-street.csv")
Crime_2021_09_oxfordshire_  = fread("data_set\\CrimeData\\2021-09\\2021-09-thames-valley-street.csv")
Crime_2021_10_oxfordshire_  = fread("data_set\\CrimeData\\2021-10\\2021-10-thames-valley-street.csv")
Crime_2021_11_oxfordshire_  = fread("data_set\\CrimeData\\2021-11\\2021-11-thames-valley-street.csv")
Crime_2021_12_oxfordshire_  = fread("data_set\\CrimeData\\2021-12\\2021-12-thames-valley-street.csv")



Crime_2022_01_oxfordshire_  = fread("data_set\\CrimeData\\2022-01\\2022-01-thames-valley-street.csv")
Crime_2022_02_oxfordshire_  = fread("data_set\\CrimeData\\2022-02\\2022-02-thames-valley-street.csv")
Crime_2022_03_oxfordshire_  = fread("data_set\\CrimeData\\2022-03\\2022-03-thames-valley-street.csv")
Crime_2022_04_oxfordshire_  = fread("data_set\\CrimeData\\2022-04\\2022-04-thames-valley-street.csv")
Crime_2022_05_oxfordshire_  = fread("data_set\\CrimeData\\2022-05\\2022-05-thames-valley-street.csv")
Crime_2022_06_oxfordshire_  = fread("data_set\\CrimeData\\2022-06\\2022-06-thames-valley-street.csv")
Crime_2022_07_oxfordshire_  = fread("data_set\\CrimeData\\2022-07\\2022-07-thames-valley-street.csv")
Crime_2022_08_oxfordshire_  = fread("data_set\\CrimeData\\2022-08\\2022-08-thames-valley-street.csv")
Crime_2022_09_oxfordshire_  = fread("data_set\\CrimeData\\2022-09\\2022-09-thames-valley-street.csv")
Crime_2022_10_oxfordshire_  = fread("data_set\\CrimeData\\2022-10\\2022-10-thames-valley-street.csv")
Crime_2022_11_oxfordshire_  = fread("data_set\\CrimeData\\2022-11\\2022-11-thames-valley-street.csv")
Crime_2022_12_oxfordshire_  = fread("data_set\\CrimeData\\2022-12\\2022-12-thames-valley-street.csv")



Crime_2023_01_oxfordshire_  = fread("data_set\\CrimeData\\2023-01\\2023-01-thames-valley-street.csv")
Crime_2023_02_oxfordshire_  = fread("data_set\\CrimeData\\2023-02\\2023-02-thames-valley-street.csv")
Crime_2023_03_oxfordshire_  = fread("data_set\\CrimeData\\2023-03\\2023-03-thames-valley-street.csv")
Crime_2023_04_oxfordshire_  = fread("data_set\\CrimeData\\2023-04\\2023-04-thames-valley-street.csv")



#north_yorkshire_
Crime_2020_05_north_yorkshire_ = fread("data_set\\CrimeData\\2020-05\\2020-05-north-yorkshire-street.csv")
Crime_2020_06_north_yorkshire_ = fread("data_set\\CrimeData\\2020-06\\2020-06-north-yorkshire-street.csv")
Crime_2020_07_north_yorkshire_ = fread("data_set\\CrimeData\\2020-07\\2020-07-north-yorkshire-street.csv")
Crime_2020_08_north_yorkshire_ = fread("data_set\\CrimeData\\2020-08\\2020-08-north-yorkshire-street.csv")
Crime_2020_09_north_yorkshire_ = fread("data_set\\CrimeData\\2020-09\\2020-09-north-yorkshire-street.csv")
Crime_2020_10_north_yorkshire_ = fread("data_set\\CrimeData\\2020-10\\2020-10-north-yorkshire-street.csv")
Crime_2020_11_north_yorkshire_ = fread("data_set\\CrimeData\\2020-11\\2020-11-north-yorkshire-street.csv")
Crime_2020_12_north_yorkshire_ = fread("data_set\\CrimeData\\2020-12\\2020-12-north-yorkshire-street.csv")



Crime_2021_01_north_yorkshire_ = fread("data_set\\CrimeData\\2021-01\\2021-01-north-yorkshire-street.csv")
Crime_2021_02_north_yorkshire_ = fread("data_set\\CrimeData\\2021-02\\2021-02-north-yorkshire-street.csv")
Crime_2021_03_north_yorkshire_ = fread("data_set\\CrimeData\\2021-03\\2021-03-north-yorkshire-street.csv")
Crime_2021_04_north_yorkshire_ = fread("data_set\\CrimeData\\2021-04\\2021-04-north-yorkshire-street.csv")
Crime_2021_05_north_yorkshire_ = fread("data_set\\CrimeData\\2021-05\\2021-05-north-yorkshire-street.csv")
Crime_2021_06_north_yorkshire_ = fread("data_set\\CrimeData\\2021-06\\2021-06-north-yorkshire-street.csv")
Crime_2021_07_north_yorkshire_ = fread("data_set\\CrimeData\\2021-07\\2021-07-north-yorkshire-street.csv")
Crime_2021_08_north_yorkshire_ = fread("data_set\\CrimeData\\2021-08\\2021-08-north-yorkshire-street.csv")
Crime_2021_09_north_yorkshire_ = fread("data_set\\CrimeData\\2021-09\\2021-09-north-yorkshire-street.csv")
Crime_2021_10_north_yorkshire_ = fread("data_set\\CrimeData\\2021-10\\2021-10-north-yorkshire-street.csv")
Crime_2021_11_north_yorkshire_ = fread("data_set\\CrimeData\\2021-11\\2021-11-north-yorkshire-street.csv")
Crime_2021_12_north_yorkshire_ = fread("data_set\\CrimeData\\2021-12\\2021-12-north-yorkshire-street.csv")



Crime_2022_01_north_yorkshire_ = fread("data_set\\CrimeData\\2022-01\\2022-01-north-yorkshire-street.csv")
Crime_2022_02_north_yorkshire_ = fread("data_set\\CrimeData\\2022-02\\2022-02-north-yorkshire-street.csv")
Crime_2022_03_north_yorkshire_ = fread("data_set\\CrimeData\\2022-03\\2022-03-north-yorkshire-street.csv")
Crime_2022_04_north_yorkshire_ = fread("data_set\\CrimeData\\2022-04\\2022-04-north-yorkshire-street.csv")
Crime_2022_05_north_yorkshire_ = fread("data_set\\CrimeData\\2022-05\\2022-05-north-yorkshire-street.csv")
Crime_2022_06_north_yorkshire_ = fread("data_set\\CrimeData\\2022-06\\2022-06-north-yorkshire-street.csv")
Crime_2022_07_north_yorkshire_ = fread("data_set\\CrimeData\\2022-07\\2022-07-north-yorkshire-street.csv")
Crime_2022_08_north_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-north-yorkshire-street.csv")
Crime_2022_09_north_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-north-yorkshire-street.csv")
Crime_2022_10_north_yorkshire_ = fread("data_set\\CrimeData\\2022-10\\2022-10-north-yorkshire-street.csv")
Crime_2022_11_north_yorkshire_ = fread("data_set\\CrimeData\\2022-11\\2022-11-north-yorkshire-street.csv")
Crime_2022_12_north_yorkshire_ = fread("data_set\\CrimeData\\2022-12\\2022-12-north-yorkshire-street.csv")



Crime_2023_01_north_yorkshire_ = fread("data_set\\CrimeData\\2023-01\\2023-01-north-yorkshire-street.csv")
Crime_2023_02_north_yorkshire_ = fread("data_set\\CrimeData\\2023-02\\2023-02-north-yorkshire-street.csv")
Crime_2023_03_north_yorkshire_ = fread("data_set\\CrimeData\\2023-03\\2023-03-north-yorkshire-street.csv")
Crime_2023_04_north_yorkshire_ = fread("data_set\\CrimeData\\2023-04\\2023-04-north-yorkshire-street.csv")



#south-yorkshire-street
Crime_2020_05_south_yorkshire_ = fread("data_set\\CrimeData\\2020-05\\2020-05-south-yorkshire-street.csv")
Crime_2020_06_south_yorkshire_ = fread("data_set\\CrimeData\\2020-06\\2020-06-south-yorkshire-street.csv")
Crime_2020_07_south_yorkshire_= fread("data_set\\CrimeData\\2020-07\\2020-07-south-yorkshire-street.csv")
Crime_2020_08_south_yorkshire_ = fread("data_set\\CrimeData\\2020-08\\2020-08-south-yorkshire-street.csv")
Crime_2020_09_south_yorkshire_= fread("data_set\\CrimeData\\2020-09\\2020-09-south-yorkshire-street.csv")
Crime_2020_10_south_yorkshire_ = fread("data_set\\CrimeData\\2020-10\\2020-10-south-yorkshire-street.csv")
Crime_2020_11_south_yorkshire_ = fread("data_set\\CrimeData\\2020-11\\2020-11-south-yorkshire-street.csv")
Crime_2020_12_south_yorkshire_ = fread("data_set\\CrimeData\\2020-12\\2020-12-south-yorkshire-street.csv")



Crime_2021_01_south_yorkshire_ = fread("data_set\\CrimeData\\2021-01\\2021-01-south-yorkshire-street.csv")
Crime_2021_02_south_yorkshire_ = fread("data_set\\CrimeData\\2021-02\\2021-02-south-yorkshire-street.csv")
Crime_2021_03_south_yorkshire_ = fread("data_set\\CrimeData\\2021-03\\2021-03-south-yorkshire-street.csv")
Crime_2021_04_south_yorkshire_ = fread("data_set\\CrimeData\\2021-04\\2021-04-south-yorkshire-street.csv")
Crime_2021_05_south_yorkshire_ = fread("data_set\\CrimeData\\2021-05\\2021-05-south-yorkshire-street.csv")
Crime_2021_06_south_yorkshire_ = fread("data_set\\CrimeData\\2021-06\\2021-06-south-yorkshire-street.csv")
Crime_2021_07_south_yorkshire_ = fread("data_set\\CrimeData\\2021-07\\2021-07-south-yorkshire-street.csv")
Crime_2021_08_south_yorkshire_ = fread("data_set\\CrimeData\\2021-08\\2021-08-south-yorkshire-street.csv")
Crime_2021_09_south_yorkshire_ = fread("data_set\\CrimeData\\2021-09\\2021-09-south-yorkshire-street.csv")
Crime_2021_10_south_yorkshire_ = fread("data_set\\CrimeData\\2021-10\\2021-10-south-yorkshire-street.csv")
Crime_2021_11_south_yorkshire_ = fread("data_set\\CrimeData\\2021-11\\2021-11-south-yorkshire-street.csv")
Crime_2021_12_south_yorkshire_ = fread("data_set\\CrimeData\\2021-12\\2021-12-south-yorkshire-street.csv")



Crime_2022_01_south_yorkshire_ = fread("data_set\\CrimeData\\2022-01\\2022-01-south-yorkshire-street.csv")
Crime_2022_02_south_yorkshire_ = fread("data_set\\CrimeData\\2022-02\\2022-02-south-yorkshire-street.csv")
Crime_2022_03_south_yorkshire_ = fread("data_set\\CrimeData\\2022-03\\2022-03-south-yorkshire-street.csv")
Crime_2022_04_south_yorkshire_ = fread("data_set\\CrimeData\\2022-04\\2022-04-south-yorkshire-street.csv")
Crime_2022_05_south_yorkshire_ = fread("data_set\\CrimeData\\2022-05\\2022-05-south-yorkshire-street.csv")
Crime_2022_06_south_yorkshire_ = fread("data_set\\CrimeData\\2022-06\\2022-06-south-yorkshire-street.csv")
Crime_2022_07_south_yorkshire_ = fread("data_set\\CrimeData\\2022-07\\2022-07-south-yorkshire-street.csv")
Crime_2022_08_south_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-south-yorkshire-street.csv")
Crime_2022_09_south_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-south-yorkshire-street.csv")
Crime_2022_09_south_yorkshire_ = fread("data_set\\CrimeData\\2022-10\\2022-10-south-yorkshire-street.csv")
Crime_2022_11_south_yorkshire_ = fread("data_set\\CrimeData\\2022-11\\2022-11-south-yorkshire-street.csv")
Crime_2022_12_south_yorkshire_ = fread("data_set\\CrimeData\\2022-12\\2022-12-south-yorkshire-street.csv")



Crime_2023_01_south_yorkshire_ = fread("data_set\\CrimeData\\2023-01\\2023-01-south-yorkshire-street.csv")
Crime_2023_02_south_yorkshire_ = fread("data_set\\CrimeData\\2023-02\\2023-02-south-yorkshire-street.csv")
Crime_2023_03_south_yorkshire_ = fread("data_set\\CrimeData\\2023-03\\2023-03-south-yorkshire-street.csv")
Crime_2023_04_south_yorkshire_ = fread("data_set\\CrimeData\\2023-04\\2023-04-south-yorkshire-street.csv")



#West-yorkshire-street
Crime_2020_05_west_yorkshire_ = fread("data_set\\CrimeData\\2020-05\\2020-05-west-yorkshire-street.csv")
Crime_2020_06_west_yorkshire_ = fread("data_set\\CrimeData\\2020-06\\2020-06-west-yorkshire-street.csv")
Crime_2020_07_west_yorkshire_= fread("data_set\\CrimeData\\2020-07\\2020-07-west-yorkshire-street.csv")
Crime_2020_08_west_yorkshire_ = fread("data_set\\CrimeData\\2020-08\\2020-08-west-yorkshire-street.csv")
Crime_2020_09_west_yorkshire_= fread("data_set\\CrimeData\\2020-09\\2020-09-west-yorkshire-street.csv")
Crime_2020_10_west_yorkshire_ = fread("data_set\\CrimeData\\2020-10\\2020-10-west-yorkshire-street.csv")
Crime_2020_11_west_yorkshire_ = fread("data_set\\CrimeData\\2020-11\\2020-11-west-yorkshire-street.csv")
Crime_2020_12_west_yorkshire_ = fread("data_set\\CrimeData\\2020-12\\2020-12-west-yorkshire-street.csv")



Crime_2021_01_west_yorkshire_ = fread("data_set\\CrimeData\\2021-01\\2021-01-west-yorkshire-street.csv")
Crime_2021_02_west_yorkshire_ = fread("data_set\\CrimeData\\2021-02\\2021-02-west-yorkshire-street.csv")
Crime_2021_03_west_yorkshire_ = fread("data_set\\CrimeData\\2021-03\\2021-03-west-yorkshire-street.csv")
Crime_2021_04_west_yorkshire_ = fread("data_set\\CrimeData\\2021-04\\2021-04-west-yorkshire-street.csv")
Crime_2021_05_west_yorkshire_ = fread("data_set\\CrimeData\\2021-05\\2021-05-west-yorkshire-street.csv")
Crime_2021_06_west_yorkshire_ = fread("data_set\\CrimeData\\2021-06\\2021-06-west-yorkshire-street.csv")
Crime_2021_07_west_yorkshire_ = fread("data_set\\CrimeData\\2021-07\\2021-07-west-yorkshire-street.csv")
Crime_2021_08_west_yorkshire_ = fread("data_set\\CrimeData\\2021-08\\2021-08-west-yorkshire-street.csv")
Crime_2021_09_west_yorkshire_ = fread("data_set\\CrimeData\\2021-09\\2021-09-west-yorkshire-street.csv")
Crime_2021_10_west_yorkshire_ = fread("data_set\\CrimeData\\2021-10\\2021-10-west-yorkshire-street.csv")
Crime_2021_11_west_yorkshire_ = fread("data_set\\CrimeData\\2021-11\\2021-11-west-yorkshire-street.csv")
Crime_2021_12_west_yorkshire_ = fread("data_set\\CrimeData\\2021-12\\2021-12-west-yorkshire-street.csv")



Crime_2022_01_west_yorkshire_ = fread("data_set\\CrimeData\\2022-01\\2022-01-west-yorkshire-street.csv")
Crime_2022_02_west_yorkshire_ = fread("data_set\\CrimeData\\2022-02\\2022-02-west-yorkshire-street.csv")
Crime_2022_03_west_yorkshire_ = fread("data_set\\CrimeData\\2022-03\\2022-03-west-yorkshire-street.csv")
Crime_2022_04_west_yorkshire_ = fread("data_set\\CrimeData\\2022-04\\2022-04-west-yorkshire-street.csv")
Crime_2022_05_west_yorkshire_ = fread("data_set\\CrimeData\\2022-05\\2022-05-west-yorkshire-street.csv")
Crime_2022_06_west_yorkshire_ = fread("data_set\\CrimeData\\2022-06\\2022-06-west-yorkshire-street.csv")
Crime_2022_07_west_yorkshire_ = fread("data_set\\CrimeData\\2022-07\\2022-07-west-yorkshire-street.csv")
Crime_2022_08_west_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-west-yorkshire-street.csv")
Crime_2022_09_west_yorkshire_ = fread("data_set\\CrimeData\\2022-08\\2022-08-west-yorkshire-street.csv")
Crime_2022_10_west_yorkshire_ = fread("data_set\\CrimeData\\2022-10\\2022-10-west-yorkshire-street.csv")
Crime_2022_11_west_yorkshire_ = fread("data_set\\CrimeData\\2022-11\\2022-11-west-yorkshire-street.csv")
Crime_2022_12_west_yorkshire_ = fread("data_set\\CrimeData\\2022-12\\2022-12-west-yorkshire-street.csv")



Crime_2023_01_west_yorkshire_ = fread("data_set\\CrimeData\\2023-01\\2023-01-west-yorkshire-street.csv")
Crime_2023_02_west_yorkshire_ = fread("data_set\\CrimeData\\2023-02\\2023-02-west-yorkshire-street.csv")
Crime_2023_03_west_yorkshire_ = fread("data_set\\CrimeData\\2023-03\\2023-03-west-yorkshire-street.csv")
Crime_2023_04_west_yorkshire_ = fread("data_set\\CrimeData\\2023-04\\2023-04-west-yorkshire-street.csv")



Crime_combined = rbind(
  Crime_2020_05_oxfordshire_, Crime_2020_06_oxfordshire_,  Crime_2020_07_oxfordshire_, Crime_2020_08_oxfordshire_,
  Crime_2020_09_oxfordshire_, Crime_2020_10_oxfordshire_, Crime_2020_11_oxfordshire_, Crime_2020_12_oxfordshire_,
  Crime_2021_01_oxfordshire_,Crime_2021_02_oxfordshire_,Crime_2021_03_oxfordshire_,Crime_2021_04_oxfordshire_,
  Crime_2021_05_oxfordshire_,Crime_2021_06_oxfordshire_,Crime_2021_07_oxfordshire_,Crime_2021_08_oxfordshire_,
  Crime_2021_09_oxfordshire_,Crime_2021_10_oxfordshire_,Crime_2021_11_oxfordshire_,Crime_2021_12_oxfordshire_,
  Crime_2022_01_oxfordshire_,Crime_2022_02_oxfordshire_,Crime_2022_03_oxfordshire_,Crime_2022_04_oxfordshire_,
  Crime_2022_05_oxfordshire_,Crime_2022_06_oxfordshire_,Crime_2022_07_oxfordshire_,Crime_2022_08_oxfordshire_,
  Crime_2022_09_oxfordshire_,Crime_2022_10_oxfordshire_,Crime_2022_11_oxfordshire_,Crime_2022_12_oxfordshire_,
  Crime_2023_01_oxfordshire_,Crime_2023_02_oxfordshire_,Crime_2023_03_oxfordshire_,Crime_2023_04_oxfordshire_,
  
  Crime_2020_05_north_yorkshire_,Crime_2020_06_north_yorkshire_,Crime_2020_07_north_yorkshire_,Crime_2020_08_north_yorkshire_,
  Crime_2020_09_north_yorkshire_,Crime_2020_10_north_yorkshire_,Crime_2020_11_north_yorkshire_,Crime_2020_12_north_yorkshire_,
  Crime_2021_01_north_yorkshire_,Crime_2021_02_north_yorkshire_,Crime_2021_02_north_yorkshire_,Crime_2021_04_north_yorkshire_,
  Crime_2021_05_north_yorkshire_,Crime_2021_06_north_yorkshire_,Crime_2021_07_north_yorkshire_,Crime_2021_08_north_yorkshire_,
  Crime_2021_09_north_yorkshire_,Crime_2021_10_north_yorkshire_,Crime_2021_11_north_yorkshire_,Crime_2021_12_north_yorkshire_,
  Crime_2022_01_north_yorkshire_,Crime_2022_02_north_yorkshire_,Crime_2022_03_north_yorkshire_,Crime_2022_04_north_yorkshire_,
  Crime_2022_05_north_yorkshire_,Crime_2022_06_north_yorkshire_,Crime_2022_07_north_yorkshire_,Crime_2022_08_north_yorkshire_,
  Crime_2022_09_north_yorkshire_,Crime_2022_10_north_yorkshire_,Crime_2022_11_north_yorkshire_,Crime_2022_12_north_yorkshire_,
  Crime_2023_01_north_yorkshire_,Crime_2023_02_north_yorkshire_,Crime_2023_03_north_yorkshire_,Crime_2023_04_north_yorkshire_,
  
  Crime_2020_05_south_yorkshire_,Crime_2020_06_south_yorkshire_,Crime_2020_07_south_yorkshire_,Crime_2020_08_south_yorkshire_,
  Crime_2020_09_south_yorkshire_,Crime_2020_10_south_yorkshire_,Crime_2020_11_south_yorkshire_,Crime_2020_12_south_yorkshire_,
  Crime_2021_01_south_yorkshire_,Crime_2021_02_south_yorkshire_,Crime_2021_03_south_yorkshire_,Crime_2021_04_south_yorkshire_,
  Crime_2021_05_south_yorkshire_,Crime_2021_06_south_yorkshire_,Crime_2021_07_south_yorkshire_,Crime_2021_08_south_yorkshire_,
  Crime_2021_09_south_yorkshire_,Crime_2021_10_south_yorkshire_,Crime_2021_11_south_yorkshire_,Crime_2021_12_south_yorkshire_,
  Crime_2022_01_south_yorkshire_,Crime_2022_02_south_yorkshire_,Crime_2022_03_south_yorkshire_,Crime_2022_04_south_yorkshire_,
  Crime_2022_05_south_yorkshire_,Crime_2022_06_south_yorkshire_,Crime_2022_07_south_yorkshire_,Crime_2022_08_south_yorkshire_,
  Crime_2022_09_south_yorkshire_,Crime_2020_10_south_yorkshire_,Crime_2022_11_south_yorkshire_,Crime_2022_12_south_yorkshire_,
  Crime_2023_01_south_yorkshire_,Crime_2023_02_south_yorkshire_,Crime_2023_03_south_yorkshire_,Crime_2023_04_south_yorkshire_,
  
  Crime_2020_05_west_yorkshire_,Crime_2020_06_west_yorkshire_,Crime_2020_07_west_yorkshire_,Crime_2020_08_west_yorkshire_,
  Crime_2020_09_west_yorkshire_,Crime_2020_10_west_yorkshire_,Crime_2020_11_west_yorkshire_,Crime_2020_12_west_yorkshire_,
  Crime_2021_01_west_yorkshire_,Crime_2021_02_west_yorkshire_,Crime_2021_03_west_yorkshire_,Crime_2021_04_west_yorkshire_,
  Crime_2021_05_west_yorkshire_,Crime_2021_06_west_yorkshire_,Crime_2021_07_west_yorkshire_,Crime_2021_08_west_yorkshire_,
  Crime_2021_09_west_yorkshire_,Crime_2021_10_west_yorkshire_,Crime_2021_11_west_yorkshire_,Crime_2021_12_west_yorkshire_,
  Crime_2022_01_west_yorkshire_,Crime_2022_02_west_yorkshire_,Crime_2022_03_west_yorkshire_,Crime_2022_04_west_yorkshire_,
  Crime_2022_05_west_yorkshire_,Crime_2022_06_west_yorkshire_,Crime_2022_07_west_yorkshire_,Crime_2022_08_west_yorkshire_,
  Crime_2022_09_west_yorkshire_,Crime_2022_10_west_yorkshire_,Crime_2022_11_west_yorkshire_,Crime_2022_12_west_yorkshire_,
  Crime_2023_01_west_yorkshire_,Crime_2023_02_west_yorkshire_,Crime_2023_03_west_yorkshire_,Crime_2023_04_west_yorkshire_
)





Crime_combined<- Crime_combined %>% 
  as_tibble()



write.csv(Crime_combined,"cleaning/cleanedData/combinedCrime.csv",row.names = FALSE)





#cleaning crime data
crime = fread('cleaning/cleanedData/combinedCrime.csv') %>% 
  select(Month, `LSOA code`, `Crime type`)



colnames(crime) = c("Year", "LSOA.code", "CrimeType")



pattern = ' .*$'
LsoaToPostcode = fread('cleaning/cleanedData/cleanedLSOA.csv')
colnames(LsoaToPostcode)=c("LSOA.code","shortPostcode","Town","District","County")
view(crime)
View(LsoaToPostcode)



crimeCleaned = crime %>%
  slice(1:10000) %>% 
  left_join(LsoaToPostcode,by="LSOA.code") %>% 
  mutate(Year = str_trim(substring(Year, 1,4))) %>% 
  group_by(shortPostcode,CrimeType,Year)%>% 
  select(shortPostcode, Year, CrimeType, ) %>% 
  na.omit() %>% 
  tally() %>% 
  as_tibble()



View(crimeCleaned)



crimeCleaned = cbind(ID = 1:nrow(crimeCleaned), crimeCleaned)  
colnames(crimeCleaned)= c("ID","shortPostcode","CrimeType","Year" , "CrimeCount")
View(crimeCleaned)
write.csv(crimeCleaned, "cleaning\\cleanedData\\cleanedCrime.csv",row.names = FALSE)

library(tidyverse)
library(dplyr)
library(scales)
library(fmsb)
library(ggrepel)
library(ggplot2)

setwd("C:\\Users\\Acer\\Desktop\\DS_Sanjeela")

euro <- dollar_format(prefix = "\u20ac", big.mark = ",")

#House Prices


Towns_Population = read_csv("Data Cleaning\\CleanedData\\PopCleanedData.csv") %>% 
  select(-Year) 
HousePrices=read_csv("Data Cleaning\\CleanedData\\HousePricingCleandata.csv", show_col_types = FALSE)


HousePricesclean <- HousePrices %>% 
  select(-PostCode) %>% 
  left_join(Towns_Population, by ="shortPostcode")


HousePricesclean$County[HousePricesclean$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"


House_town = HousePricesclean %>% 
  #filter(County=="OXFORDSHIRE"|County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  filter(County=="OXFORDSHIRE"|County=="YORKSHIRE") %>% 
  group_by(Town,District,County,Year) %>% 
  summarise(AveragePrice= mean(Price)) %>% 
  ungroup(Town,District,County,Year) %>%
  na.omit()
write.csv(House_town,"Data Cleaning\\CleanedData\\Town_House.csv",row.names = FALSE)



# BOXPLOT Average house prices (2022)
House_town %>% 
  group_by(District) %>% 
  ggplot(aes(x = District, y = AveragePrice, fill=District)) +
  scale_y_continuous(limits=c(0,2000000), breaks = seq(0,2000000,200000), 
                     label = euro) +
  geom_boxplot() +
  coord_flip() +
  labs(title="2022 house prices by district")


# BARGRAPH houseprices by district (2019-2022)

HousePricesclean %>%
  group_by(District) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = District, y = AveragePrice)) +
  geom_bar(position = "stack",stat = "identity", fill = "cornflowerblue") +
  scale_y_continuous(limits=c(0,5000000),breaks = seq(0, 5000000, 30000),
                     label = euro) +
  geom_text(aes(label = euro(AveragePrice)),
            vjust = -0.25) +
  labs(title = "2019-2022 Average house prices by district") +
  coord_flip()


#LINEGRAPH Average house prices by year (2019-2022)

HousePricesclean %>%
  mutate(Year = as.numeric(Year)) %>%  # Convert Year to numeric if not already
  group_by(Year) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = Year, y = AveragePrice)) +
  geom_line(size = 1.5, color = "blue") +
  geom_text(aes(label = dollar_format()(AveragePrice)), vjust = -0.85) +
  scale_y_continuous(labels = dollar_format(prefix = "$"), breaks = seq(0, 300000, 5000)) +
  scale_x_continuous(breaks = seq(2019, 2022, 1), minor_breaks = NULL) +
  geom_point(size = 2, color = "steelblue") +
  labs(title = "2019-2022 Average house prices by year",
       x = "Year",
       y = "Average Price")




# Read the CSV file and assign the year
School_2021_2022 <- fread("D:\\datasci\\School_2021-2022\\2021-2022\\england_ks4final.csv", fill = TRUE) %>%
  mutate(Year = 2021)

# Select relevant columns, remove missing values, and keep distinct records
School_2021_2022 <- School_2021_2022 %>%
  select(Year, PCODE, SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()



#--------------------------------------------------SCHOOL--------------------------------------------------------------
# Read the CSV file and assign the year
School_2021_2022 <- fread("Data_set\\School\\school2021.csv", fill = TRUE) %>%
  mutate(Year = 2021)

# Select relevant columns, remove missing values, and keep distinct records
School_2021_2022 <- School_2021_2022 %>%
  select(Year, PCODE, SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()

# Read the CSV file and assign the year
School_2022_2023 <- fread("Data_set\\School\\school2021.csv", fill = TRUE) %>%
  mutate(Year = 2022)

# Select relevant columns, remove missing values, and keep distinct records
School_2022_2023 = School_2022_2023 %>%
  select(Year, PCODE, SCHNAME, ATT8SCR) %>%
  drop_na() %>%
  distinct()


combinedschool = rbind(School_2021_2022,School_2022_2023)
write.csv(combinedschool, "cleaning\\cleanedDataSchoolCombinedData.csv",row.names = FALSE)


pattern = ' .*$'

Cleanedcombinedschool = combinedschool %>% 
  mutate(ID = row_number()) %>% 
  mutate(shortPostcode=gsub(pattern,"",PCODE)) %>%
  filter (ATT8SCR != "NE" & ATT8SCR != "SUPP") %>% 
  filter(ATT8SCR !=""& shortPostcode!=""& PCODE!="") %>% 
  select( ID,Year,PCODE,shortPostcode,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()
View(Cleanedcombinedschool)
colnames(Cleanedcombinedschool) = c("ID", "Year", "Postcode", "shortPostcode", "SchoolName", "Attainment8Score")

write.csv(Cleanedcombinedschool, "cleaning\\cleanedData\\SchoolCleanData.csv",row.names = FALSE)


Post=read.csv("cleaning\\cleanedData\\Combined_housePricing.csv") %>% 
  select(PostCode,County) %>% 
  mutate(shortPostcode=gsub(pattern,"",PostCode)) %>% 
  select(county,shortPostcode)

# School data cleaning seperatly for OXFORDSHIRE and YORKSHIRE

OXFORDSHIRESchoolData = Cleanedcombinedschool %>% 
  left_join(Post,by = "shortPostcode") %>% 
  select(Year, Postcode, shortPostcode, SchoolName, Attainment8Score,county) %>% 
  filter(county=="OXFORDSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, Postcode, shortPostcode, SchoolName, Attainment8Score)

write.csv(OXFORDSHIRESchoolData, "cleaning\\CleanedData\\OXFORDSHIRESchoolData.csv",row.names = FALSE) 

YORKSHIRESchoolData = Cleanedcombinedschool %>% 
  left_join(Post,by = "shortPostcode") %>% 
  select(Year, Postcode, shortPostcode, SchoolName, Attainment8Score,county) %>% 
  filter(county=="YORK" | county=="WEST YORKSHIRE" | county=="SOUTH YORKSHIRE" | county=="NORTH YORKSHIRE") %>% 
  na.omit() %>% 
  distinct() %>% 
  mutate(ID = row_number()) %>% 
  select(ID,Year, Postcode, shortPostcode, SchoolName, Attainment8Score)

View(YORKSHIRESchoolData)

write.csv(YORKSHIRESchoolData, "cleaning\\cleanedData\\YORKSHIRESchoolData.csv",row.names = FALSE) 

#--------------
Town = read_csv("cleaning\\leanedData\\PopCleanedData.csv")%>% 
  select(shortPostcode,District)


schoolData = read_csv("cleaning\\leanedData\\SchoolCombinedData.csv", show_col_types = FALSE)
view(Town)
view(schoolData)
view(YORKSHIREschool)
view(group_by(OXFORSSHIRESchoolData,shortPostcode))

#to include information about the town associated with each school in the schoolData, the join would allow you to add columns from the Town data frame (such as town name, population, geographic details, etc.) to the schoolData data frame.schoolData = schoolData %>% 
schoolData = schoolData %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()

